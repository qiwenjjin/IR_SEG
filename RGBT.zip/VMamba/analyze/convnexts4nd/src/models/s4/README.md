The standalone S4 implementation used to live here, but has been moved to [models/s4](/models/s4).
