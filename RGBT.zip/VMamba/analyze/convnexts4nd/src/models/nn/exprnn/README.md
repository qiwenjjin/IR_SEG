Original code from https://github.com/Lezcano/expRNN

This was extracted around early 2020 and may not be the most recent version, but is compatible with this codebase.
